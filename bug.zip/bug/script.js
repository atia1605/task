const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const winVideo = document.getElementById("winVideo");
const winAudio = document.getElementById("winAudio");

let bugX = canvas.width / 2;
let bugY = canvas.height / 2;
let bugSize = 30;
let interval = 1000;
let score = 0;
let isGameOver = false;



let lastTime = 0;
let bugInterval;

var backgroundImage = new Image();
backgroundImage.src = "backk.jpeg"; // Replace "background.jpg" with your background image path

const bugImage = new Image();
bugImage.src = "bugg.png"; // Replace "bug.png" with your bug image path

function drawBug() {
    // Draw the background image
    ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);

    // Draw the bug image
    const bugWidth = 100;  // Set the width of the bug image
    const bugHeight = 100; // Set the height of the bug image
    ctx.drawImage(bugImage, bugX - bugWidth / 2, bugY - bugHeight / 2, bugWidth, bugHeight);
    
}

function moveBug() {
    if (!isGameOver) {
        bugX = Math.random() * canvas.width;
        bugY = Math.random() * canvas.height;
        drawBug();
    }
}

function updateScore() {
    score++;
    document.getElementById("scoreValue").textContent = score;
}

function decreaseInterval() {
    interval -= 100;
}

function resetSpeed() {
    interval = 1000;
}

function resetScore() {
    score = 0;
    document.getElementById("scoreValue").textContent = score;
}

function drawVideoFrame() {
    // Draw the current video frame onto the canvas
    ctx.drawImage(winVideo, 0, 0, canvas.width, canvas.height);

    // Request the next frame
    requestAnimationFrame(drawVideoFrame);
}

const clickSound = document.getElementById("clickSound");

canvas.addEventListener("click", function(event) {
    const rect = canvas.getBoundingClientRect();
    const clickX = event.clientX - rect.left;
    const clickY = event.clientY - rect.top;

    const distance = Math.sqrt((clickX - bugX) ** 2 + (clickY - bugY) ** 2);
    if (distance < bugSize) {
        // Bug is clicked, trigger smashing effect
        isGameOver = true;
        clickSound.play();
        drawSmashedBug();
        updateScore();
        decreaseInterval();
        if (score === 10) {
            // Show the winning video
            winVideo.style.display = "block";
            winVideo.play();
            winAudio.play();
    
            // Start drawing the video frame onto the canvas
            drawVideoFrame();

            winVideo.style.display = "none";
        }
   

        setTimeout(function() {
            isGameOver = false;
            moveBug();
        }, interval);
    }
});

function drawSmashedBug() {
    
    // Draw smashed image
    const img = new Image();
    img.onload = function() {
        ctx.drawImage(img, bugX - bugSize / 2, bugY - bugSize / 2, bugSize, bugSize);
    }
    img.src = "smashed.jpeg"; // Replace with your smashed bug image path
    img.width = bugSize; // Set the image width to match the bug size
    img.height = bugSize;
}

document.getElementById("resetScore").addEventListener("click", resetScore);
document.getElementById("resetSpeed").addEventListener("click", resetSpeed);

moveBug(); // Start the game by moving the bug initially
setInterval(moveBug, interval); // Start moving the bug at a regular interval