"use strict";
/*  
      Project to create a timer object
      Author:Atia Nahia
      Date:  17/04/2024

*/

/*--------------- Object Code --------------------*/

function Timer(min, sec, millisec) {
   this.minutes = min;
   this.seconds = sec;
   this.milliseconds = millisec;
   this.timeID = null;
}

Timer.prototype.runPause = function(minBox, secBox, millisecBox) {
   if (this.timeID) {
      window.clearInterval(this.timeID);
      this.timeID = null;
   } else {
      this.timeID = window.setInterval(() => {
         this.countdown(minBox, secBox, millisecBox);
      }, 100); // Run countdown every 100 milliseconds
   }
};

Timer.prototype.countdown = function(minBox, secBox, millisecBox) {
   if (this.milliseconds > 0) {
      this.milliseconds -= 100;
   } else {
      if (this.seconds > 0) {
         this.seconds -= 1;
         this.milliseconds = 900; // Reset milliseconds to 900 when seconds decrease
      } else {
         if (this.minutes > 0) {
            this.minutes -= 1;
            this.seconds = 59; // Reset seconds to 59 when minutes decrease
            this.milliseconds = 900; // Reset milliseconds to 900 when minutes decrease
         } else {
            // Timer reached 0:0:0
            window.clearInterval(this.timeID);
            this.timeID = null;
         }
      }
   }

   // Update values in UI
   minBox.value = this.minutes;
   secBox.value = this.seconds;
   millisecBox.value = this.milliseconds;
};

/*---------------Interface Code -----------------*/

/* Interface Objects */
let minBox = document.getElementById("minutesBox");
let secBox = document.getElementById("secondsBox");
let millisecBox = document.getElementById("millisecsBox");
let runPauseTimer = document.getElementById("runPauseButton");

/* Event Listeners */
minBox.onchange = function() {
   myTimer.minutes = parseInt(minBox.value);
};

secBox.onchange = function() {
   myTimer.seconds = parseInt(secBox.value);
};

millisecBox.onchange = function() {
   myTimer.milliseconds = parseInt(millisecBox.value);
};

runPauseTimer.onclick = function() {
   myTimer.runPause(minBox, secBox, millisecBox);
};

/* Timer Initialization */
let myTimer = new Timer(parseInt(minBox.value), parseInt(secBox.value), parseInt(millisecBox.value));
