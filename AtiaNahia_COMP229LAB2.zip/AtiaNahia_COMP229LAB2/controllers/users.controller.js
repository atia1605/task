const bcrypt = require("bcryptjs");

// In-memory users array to simulate a database
const users = [];

// Get All Users
exports.getAllUsers = (req, res) => {
  const userList = users.map((user) => ({
    name: user.name,
    email: user.email,
  }));
  res.json(userList);
};

// Register New User (Sign Up)
exports.signup = async (req, res) => {
  const { name, email, password } = req.body;
  const existingUser = users.find((user) => user.email === email);
  if (existingUser) {
    return res.status(400).json({ message: "User already exists" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = { name, email, password: hashedPassword };
  users.push(newUser);
  res
    .status(201)
    .json({ message: "User registered successfully", user: { name, email } });
};

// Log User In
exports.login = async (req, res) => {
  const { email, password } = req.body;
  const user = users.find((user) => user.email === email);
  if (!user) {
    return res.status(400).json({ message: "Invalid email or password" });
  }

  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    return res.status(400).json({ message: "Invalid email or password" });
  }

  res.json({ message: "Login successful" });
};

// Correctly export the functions
module.exports = {
  getAllUsers: exports.getAllUsers,
  signup: exports.signup,
  login: exports.login,
};