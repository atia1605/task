const express = require("express");
const app = express();
const userRoutes = require("./routes/users.route");

const PORT = 7878;

app.use(express.json()); // To parse JSON request body

app.get("/", (req, res) => {
  res.send("The server is up...");
});

app.use("/api/users", userRoutes); // User routes

app.listen(PORT, () => {
  console.log("Server running on port " + PORT);
});
