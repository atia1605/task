const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  productName: {
    type: String,
    required: true,
    minlength: 3, // Ensure productName is at least 3 characters
  },
  company: {
    type: String,
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 1 // Ensure quantity is at least 1
  },
  productPrice: {
    type: Number,
    required: true,
    min: 0.01 // Ensure productPrice is at least 0.01
  }
}, { timestamps: true });

const Product = mongoose.model('Product', productSchema);

module.exports = Product;
