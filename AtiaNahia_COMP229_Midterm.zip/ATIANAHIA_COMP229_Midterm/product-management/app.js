require('dotenv').config(); // This should be at the top of your index.js file
const express = require('express');
const mongoose = require('mongoose');
const productRoutes = require('./routes/productRoutes'); // Ensure the path is correct

const app = express();
const PORT = process.env.PORT || 7050;

// Middleware
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('Connected to database:', process.env.DB_NAME);
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Routes
app.use('/api/routes', productRoutes); // Ensure this line comes after you've defined the routes
app.get('/', (_req, res) => {
  res.send('Welcome to the Product Management API');
});

